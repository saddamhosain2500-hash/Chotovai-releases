#!/data/data/com.termux/files/usr/bin/bash
# Download the newest Chotovai agent from the public releases repo and unpack it over this folder.
# Your .env (keys) and data/ (memory, reminders) are not in the zip, so they are kept.
# Everything is inside main() so bash reads the whole file before running it —
# that way replacing this very script during the update can't break the run.
main() {
  BASE="https://raw.githubusercontent.com/saddamhosain2500-hash/Chotovai-releases/main"
  DIR="$(cd "$(dirname "$0")" && pwd)"
  CUR="$(cat "$DIR/VERSION" 2>/dev/null || echo 0)"
  TMP="$DIR/data/update"; rm -rf "$TMP"; mkdir -p "$TMP"

  # GitHub API, not raw.githubusercontent.com (that CDN can hand out a 5-minute-old copy after a release)
  JSON="$(curl -fsSL -m 30 "https://raw.githubusercontent.com/saddamhosain2500-hash/Chotovai-releases/main/latest.json?t=$(date +%s)" || curl -fsSL -m 30 -H 'Accept: application/vnd.github.raw' "https://api.github.com/repos/saddamhosain2500-hash/Chotovai-releases/contents/latest.json")" || { echo "❌ GitHub-এ পৌঁছানো যায়নি"; exit 1; }
  NEW="$(printf '%s' "$JSON" | grep -o '"version": *[0-9]*' | grep -o '[0-9]*$')"
  URL="$(printf '%s' "$JSON" | grep -o '"agent": *"[^"]*"' | cut -d'"' -f4)"
  [ -n "$NEW" ] && [ -n "$URL" ] || { echo "❌ নতুন ভার্সনের তথ্য পাওয়া যায়নি"; exit 1; }
  if [ "$NEW" -le "$CUR" ] 2>/dev/null && [ "$1" != "--force" ]; then echo "ℹ️ বট আগে থেকেই সর্বশেষ ভার্সনে আছে (v$CUR)"; exit 0; fi

  curl -fsSL -m 120 -o "$TMP/agent.zip" "$URL" || { echo "❌ ডাউনলোড হয়নি"; exit 1; }
  unzip -q -o "$TMP/agent.zip" -d "$TMP" && [ -f "$TMP/chotovai-agent/src/index.js" ] || { echo "❌ ফাইলটা নষ্ট"; exit 1; }
  # replace files atomically (write .new, then rename) so a running run.sh is never read half-written
  (cd "$TMP/chotovai-agent" && find . -type f) | while read -r f; do
    mkdir -p "$DIR/$(dirname "$f")"
    cp "$TMP/chotovai-agent/$f" "$DIR/$f.new" && mv -f "$DIR/$f.new" "$DIR/$f"
  done
  chmod +x "$DIR"/*.sh
  rm -rf "$TMP"
  echo "✅ বট আপডেট হয়েছে: v$CUR → v$(cat "$DIR/VERSION")"
}
main "$@"; exit $?
