#!/data/data/com.termux/files/usr/bin/bash
# Connect this phone's bot to the Upay DSO phone over Wi-Fi (Android "Wireless debugging").
cd "$(dirname "$0")"
say() { printf '\n\033[1;36m%s\033[0m\n' "$*"; }

say "১/৪  adb বসাচ্ছি…"
pkg install -y android-tools >/dev/null 2>&1 || { echo "android-tools বসানো যায়নি"; exit 1; }
adb start-server >/dev/null 2>&1

cat <<'TXT'

২/৪  DSO ফোনে:
  Settings → Developer options → Wireless debugging (নামের ওপর চাপো, সুইচে না)
  → "Pair device with pairing code" চাপো।
  একটা ৬ অঙ্কের কোড আর "IP address & Port" দেখাবে (যেমন 192.168.0.105:37123)।
  ওই পাতা খোলা রেখেই নিচে লেখো।
TXT
echo "(আগেই pair করা থাকলে দুটো প্রশ্নেই শুধু Enter চাপো)"
read -rp "Pairing-এর IP address & Port: " PAIR
if [ -n "$PAIR" ]; then
  read -rp "৬ অঙ্কের Pairing code: " CODE
  OUT=$(adb pair "$PAIR" "$CODE" 2>&1); echo "$OUT"
  if ! echo "$OUT" | grep -qi "successfully paired"; then
    echo "⚠️  adb বলছে pairing নিশ্চিত হয়নি। DSO ফোনের Wireless debugging → \"Paired devices\"-এ নতুন কিছু এসেছে কিনা দেখো।"
    echo "    এসে থাকলে সব ঠিক আছে — চালিয়ে যাও। না এলে Ctrl+C চেপে আবার চেষ্টা করো।"
  fi
fi

cat <<'TXT'

৩/৪  এবার DSO ফোনে Pairing-এর ছোট পাতাটা বন্ধ করো।
  Wireless debugging পাতার একদম ওপরে "IP address & Port" লেখা আছে
  (Pairing-এর পোর্ট থেকে আলাদা) — সেটা লেখো।
TXT
read -rp "IP address & Port: " CONN
OUT=$(adb connect "$CONN" 2>&1); echo "$OUT"
if ! echo "$OUT" | grep -qi "connected to" || echo "$OUT" | grep -qi "failed\|unable"; then
  if ping -c 2 -W 2 "${CONN%%:*}" >/dev/null 2>&1; then
    say "❌ যুক্ত হয়নি। ফোন দুটো একে অপরকে দেখতে পাচ্ছে, তাই সম্ভবত pairing হয়নি বা পোর্ট ভুল। আবার pair করে চালাও।"
  else
    say "❌ যুক্ত হয়নি — DSO ফোনে পৌঁছানোই যাচ্ছে না। হয় দুটো ফোন আলাদা Wi-Fi-তে, নয়তো রাউটার ফোনগুলোকে একে অপরের সাথে কথা বলতে দিচ্ছে না (AP isolation)।"
  fi
  exit 1
fi

say "৪/৪  পরীক্ষা করছি…"
adb -s "$CONN" shell svc power stayon true    # keep the DSO phone's screen on while it is charging
SIZE=$(adb -s "$CONN" shell wm size | tr -d '\r')
echo "DSO ফোনের স্ক্রিন: $SIZE"
touch .env
if grep -q '^DSO_ADB=' .env; then sed -i "s|^DSO_ADB=.*|DSO_ADB=$CONN|" .env; else echo "DSO_ADB=$CONN" >> .env; fi
say "✅ DSO ফোন যুক্ত হয়েছে! এখন ছোটভাই অ্যাপে ↻ রিস্টার্ট চাপো, তারপর বটকে বলো: \"DSO ফোনের স্ক্রিন দেখাও\""
