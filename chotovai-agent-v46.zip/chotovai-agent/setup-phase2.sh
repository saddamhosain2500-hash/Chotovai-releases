#!/data/data/com.termux/files/usr/bin/bash
# Chotovai Agent — Phase 2 setup: Google Drive, MEGA, Gmail, voice
cd "$(dirname "$0")"
[ -f .env ] || { echo "❌ আগে install.sh চালাও"; exit 1; }

set_env() { # set_env KEY VALUE  (no sed, so any characters are safe)
  grep -v "^$1=" .env > .env.tmp || true
  printf '%s=%s\n' "$1" "$2" >> .env.tmp
  mv .env.tmp .env && chmod 600 .env
}
ask() { read -rp "$1 (y/n): " a; [[ "$a" == [yYহ]* ]]; }

echo "📦 দরকারি প্যাকেজ ইনস্টল হচ্ছে (rclone, python, ffmpeg)…"
pkg install -y rclone python ffmpeg || { echo "❌ প্যাকেজ ইনস্টল হয়নি"; exit 1; }
grep -q "^VOICE_MODEL=" .env || set_env VOICE_MODEL "google/gemini-3.1-flash-lite"

echo
echo "━━━━━━━━━━ ১. Google Drive ━━━━━━━━━━"
if ask "📁 Google Drive যুক্ত করবে?"; then
  echo
  echo "এখন একটা লিংক দেখাবে (http://127.0.0.1:53682/auth…)।"
  echo "লিংকটা লম্বা চেপে Open করো → Google দিয়ে লগইন → Allow চাপো → 'Success' দেখলে Termux-এ ফিরে এসো।"
  echo
  rclone config delete gdrive >/dev/null 2>&1
  # stdout holds the saved config incl. the OAuth token — never show it; the login link goes to stderr
  if rclone config create gdrive drive scope drive >/dev/null && rclone about gdrive: >/dev/null 2>&1; then
    echo "✅ Google Drive যুক্ত হয়েছে"
  else
    echo "❌ Google Drive যুক্ত হয়নি — পরে আবার চেষ্টা করো"
  fi
fi

echo
echo "━━━━━━━━━━ ২. MEGA ━━━━━━━━━━"
if ask "☁️ MEGA যুক্ত করবে?"; then
  read -rp "MEGA ইমেইল: " ME
  read -rsp "MEGA পাসওয়ার্ড (টাইপ করলে দেখা যাবে না): " MP; echo
  rclone config delete mega >/dev/null 2>&1
  if rclone config create mega mega user "$ME" pass "$MP" --obscure >/dev/null && rclone about mega: >/dev/null 2>&1; then
    echo "✅ MEGA যুক্ত হয়েছে"
  else
    echo "❌ MEGA লগইন হয়নি — ইমেইল/পাসওয়ার্ড দেখো। MEGA-তে 2FA চালু থাকলে জানিও।"
    rclone config delete mega >/dev/null 2>&1
  fi
  unset MP
fi

echo
echo "━━━━━━━━━━ ৩. Gmail ━━━━━━━━━━"
if ask "📧 Gmail যুক্ত করবে?"; then
  echo
  echo "দরকার একটা 'App password' (সাধারণ পাসওয়ার্ড না):"
  echo " ১) Google অ্যাকাউন্টে 2-Step Verification চালু থাকতে হবে"
  echo " ২) Chrome-এ যাও: myaccount.google.com/apppasswords"
  echo " ৩) নাম দাও 'Chotovai' → Create → ১৬ অক্ষরের পাসওয়ার্ড কপি করো"
  echo
  read -rp "Gmail ঠিকানা: " GA
  read -rsp "App password (টাইপ/পেস্ট করলে দেখা যাবে না): " GP; echo
  GP="${GP// /}"
  RESULT=$(printf '{"count":1}' | GMAIL_ADDRESS="$GA" GMAIL_APP_PASSWORD="$GP" python3 tools/mail.py list)
  if echo "$RESULT" | grep -q "^uid\|কোনো ইমেইল পাওয়া যায়নি"; then
    set_env GMAIL_ADDRESS "$GA"; set_env GMAIL_APP_PASSWORD "$GP"
    echo "✅ Gmail যুক্ত হয়েছে"
  else
    echo "❌ Gmail যুক্ত হয়নি: $RESULT"
  fi
  unset GP
fi

echo
echo "━━━━━━━━━━ শেষ ━━━━━━━━━━"
echo "যুক্ত ক্লাউড: $(rclone listremotes | tr '\n' ' ')"
grep -q "^GMAIL_ADDRESS=." .env && echo "Gmail: যুক্ত" || echo "Gmail: যুক্ত নেই"
echo
echo "এখন বট চালু করো:  node src/index.js"
echo "(পরে যেকোনো সময় আবার এই স্ক্রিপ্ট চালিয়ে কিছু যোগ/বদল করা যাবে)"
