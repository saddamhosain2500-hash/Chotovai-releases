#!/usr/bin/env python3
"""Gmail helper for Chotovai Agent.

Reads mail over IMAP and sends over SMTP using a Gmail *app password*.
Credentials come from env: GMAIL_ADDRESS, GMAIL_APP_PASSWORD.
Usage: echo '{"count":5,"query":"is:unread"}' | python3 mail.py list
       echo '{"uid":"1234"}' | python3 mail.py read
       echo '{"to":"a@b.com","subject":"Hi","body":"..."}' | python3 mail.py send
Only the Python standard library is used.
"""
import html
import imaplib
import json
import os
import re
import smtplib
import sys
from email import message_from_bytes
from email.header import decode_header, make_header
from email.message import EmailMessage
from email.utils import parsedate_to_datetime, parseaddr

ADDR = os.environ.get("GMAIL_ADDRESS", "").strip()
PW = os.environ.get("GMAIL_APP_PASSWORD", "").replace(" ", "").strip()


def out(msg):
    print(msg)
    sys.exit(0)


def hdr(value):
    try:
        return str(make_header(decode_header(value or "")))
    except Exception:
        return value or ""


def connect():
    m = imaplib.IMAP4_SSL("imap.gmail.com", 993, timeout=40)
    m.login(ADDR, PW)
    return m


def all_mail(m):
    """Find Gmail's 'All Mail' folder by its \\All flag (its name changes with the account language)."""
    try:
        typ, data = m.list()
        for line in data or []:
            if isinstance(line, bytes) and b"\\All" in line:
                mt = re.match(rb'\(.*?\) "(?:[^"]*)" (.+)$', line)
                if mt:
                    return mt.group(1).decode()
    except Exception:
        pass
    return "INBOX"


def body_text(msg):
    plain, htm, atts = None, None, []
    for part in msg.walk():
        if part.is_multipart():
            continue
        fname = part.get_filename()
        if fname or part.get_content_disposition() == "attachment":
            atts.append(hdr(fname or "attachment"))
            continue
        ctype = part.get_content_type()
        try:
            payload = part.get_payload(decode=True) or b""
            txt = payload.decode(part.get_content_charset() or "utf-8", "replace")
        except Exception:
            continue
        if ctype == "text/plain" and plain is None:
            plain = txt
        elif ctype == "text/html" and htm is None:
            htm = txt
    if plain is None and htm:
        t = re.sub(r"(?is)<(script|style).*?</\1>", "", htm)
        t = re.sub(r"(?i)<br\s*/?>|</p>|</div>|</tr>", "\n", t)
        t = re.sub(r"<[^>]+>", " ", t)
        plain = html.unescape(t)
    plain = re.sub(r"[ \t]+", " ", plain or "")
    plain = re.sub(r"\n\s*\n+", "\n\n", plain).strip()
    return plain, atts


def short_date(value):
    try:
        return parsedate_to_datetime(value).strftime("%d/%m %H:%M")
    except Exception:
        return (value or "")[:16]


def cmd_list(a):
    count = max(1, min(int(a.get("count") or 10), 30))
    query = (a.get("query") or "").strip()
    m = connect()
    m.select("INBOX" if not query else all_mail(m), readonly=True)
    if query:
        # Gmail search syntax (is:unread, from:x, newer_than:2d …), sent as a UTF-8 literal
        m.literal = query.encode("utf-8")
        typ, data = m.uid("SEARCH", "CHARSET", "UTF-8", "X-GM-RAW")
    else:
        typ, data = m.uid("SEARCH", None, "ALL")
    uids = (data[0] or b"").split()
    if not uids:
        out("কোনো ইমেইল পাওয়া যায়নি।")
    uids = uids[-count:][::-1]
    rows = []
    for uid in uids:
        typ, d = m.uid("FETCH", uid, "(FLAGS BODY.PEEK[HEADER.FIELDS (FROM SUBJECT DATE)])")
        raw, flags = b"", b""
        for item in d:
            if isinstance(item, tuple):
                flags, raw = item[0], item[1]
        h = message_from_bytes(raw)
        name, addr = parseaddr(hdr(h.get("From")))
        unread = "" if b"\\Seen" in flags else " 🔵"
        rows.append(f"uid {uid.decode()} | {short_date(h.get('Date'))} | {name or addr} | {hdr(h.get('Subject'))}{unread}")
    m.logout()
    out("\n".join(rows) + "\n(🔵 = না-পড়া)")


def cmd_read(a):
    uid = str(a.get("uid") or "").strip()
    if not uid.isdigit():
        out("uid দাও (email_list থেকে)।")
    m = connect()
    m.select(all_mail(m), readonly=True)
    typ, d = m.uid("FETCH", uid, "(BODY.PEEK[])")
    raw = next((x[1] for x in d if isinstance(x, tuple)), None)
    m.logout()
    if not raw:
        out("এই uid-এ কোনো ইমেইল নেই।")
    msg = message_from_bytes(raw)
    text, atts = body_text(msg)
    lines = [
        f"From: {hdr(msg.get('From'))}",
        f"To: {hdr(msg.get('To'))}",
        f"Date: {msg.get('Date')}",
        f"Subject: {hdr(msg.get('Subject'))}",
    ]
    if atts:
        lines.append("Attachments: " + ", ".join(atts))
    lines.append("")
    lines.append(text[:6000] + ("\n…(বাকিটা কাটা হয়েছে)" if len(text) > 6000 else ""))
    out("\n".join(lines))


def cmd_send(a):
    to, subject, body = (a.get("to") or "").strip(), a.get("subject") or "", a.get("body") or ""
    if "@" not in to:
        out("প্রাপকের সঠিক ইমেইল ঠিকানা দাও।")
    msg = EmailMessage()
    msg["From"], msg["To"], msg["Subject"] = ADDR, to, subject
    msg.set_content(body)
    with smtplib.SMTP_SSL("smtp.gmail.com", 465, timeout=40) as s:
        s.login(ADDR, PW)
        s.send_message(msg)
    out(f"পাঠানো হয়েছে → {to}")


def main():
    if not ADDR or not PW:
        out("Gmail যুক্ত করা নেই। Termux-এ `bash setup-phase2.sh` চালাও।")
    cmd = sys.argv[1] if len(sys.argv) > 1 else ""
    try:
        args = json.loads(sys.stdin.read() or "{}")
    except Exception:
        args = {}
    try:
        {"list": cmd_list, "read": cmd_read, "send": cmd_send}.get(cmd, lambda _: out("অজানা কমান্ড"))(args)
    except imaplib.IMAP4.error as e:
        out(f"Gmail লগইন/খোঁজায় সমস্যা: {e}. App password ঠিক আছে কিনা দেখো।")
    except smtplib.SMTPAuthenticationError:
        out("Gmail লগইন হয়নি — App password ভুল বা বাতিল।")
    except Exception as e:
        out(f"Gmail সমস্যা: {type(e).__name__}: {e}")


if __name__ == "__main__":
    main()
