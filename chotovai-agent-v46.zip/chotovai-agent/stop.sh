#!/data/data/com.termux/files/usr/bin/bash
# Stop every running copy of the agent (and its auto-restart loop)
pkill -f "chotovai-agent/run.sh" 2>/dev/null
pkill -f "bash run.sh" 2>/dev/null
pkill -f "node src/index.js" 2>/dev/null
sleep 1
rm -f "$(cd "$(dirname "$0")" && pwd)/data/agent.pid"
echo "⏹ বট বন্ধ"
