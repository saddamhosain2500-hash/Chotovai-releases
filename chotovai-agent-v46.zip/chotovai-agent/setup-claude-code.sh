#!/data/data/com.termux/files/usr/bin/bash
# Claude Code on the phone (inside Ubuntu via proot-distro), signed in with your Claude Pro/Max plan.
# After this, the bot hands big coding jobs to Claude Code instead of spending OpenRouter credit.
set -e

say() { printf '\n\033[1;36m%s\033[0m\n' "$*"; }

say "১/৪  দরকারি প্যাকেজ বসাচ্ছি (git, proot-distro)…"
pkg install -y git proot-distro >/dev/null

if proot-distro login ubuntu -- true 2>/dev/null; then
  say "২/৪  Ubuntu আগে থেকেই আছে ✓"
else
  say "২/৪  Ubuntu বসাচ্ছি (প্রায় ৩০০MB নামবে, কয়েক মিনিট লাগবে)…"
  proot-distro install ubuntu
fi

say "৩/৪  Ubuntu-র ভেতরে Claude Code বসাচ্ছি…"
proot-distro login ubuntu -- bash -lc '
  set -e
  export DEBIAN_FRONTEND=noninteractive
  apt-get update -qq
  apt-get install -y -qq curl git ca-certificates >/dev/null
  curl -fsSL https://claude.ai/install.sh | bash
  grep -q ".local/bin" ~/.bashrc 2>/dev/null || echo "export PATH=\"\$HOME/.local/bin:\$PATH\"" >> ~/.bashrc
  export PATH="$HOME/.local/bin:$PATH"
  claude --version
'

say "৪/৪  এবার তোমার Claude অ্যাকাউন্টে লগইন"
cat <<'TXT'
এখন Claude Code খুলবে। যা করবে:
  • রঙের থিম জিজ্ঞেস করলে Enter চাপো
  • লগইনের ধরন জিজ্ঞেস করলে বেছে নাও: "Claude account with subscription" (Pro)
  • একটা লিংক দেখাবে — লম্বা চেপে কপি করে ব্রাউজারে খোলো, Authorize চাপো
  • ব্রাউজারে যে কোড দেখাবে সেটা কপি করে এখানে পেস্ট করো, Enter
  • "Login successful" দেখালে লেখো  /exit  তারপর Enter
TXT
read -rp "তৈরি হলে Enter চাপো… " _
proot-distro login ubuntu -- bash -lc 'export PATH="$HOME/.local/bin:$PATH"; cd /root && claude' || true

say "পরীক্ষা করছি…"
if proot-distro login ubuntu -- bash -lc 'export PATH="$HOME/.local/bin:$PATH"; cd /tmp && claude -p "Reply with just: OK" --max-turns 1' 2>&1 | tee /dev/stderr | grep -q "OK"; then
  say "✅ Claude Code প্রস্তুত! এখন ছোটভাই অ্যাপে ↻ রিস্টার্ট চাপো — তারপর বট বড় কোডের কাজ এটা দিয়েই করবে।"
else
  say "❌ পরীক্ষা পাস করেনি। লগইন ঠিকমতো হয়েছে কিনা দেখো, তারপর এই স্ক্রিপ্ট আবার চালাও।"
fi
