#!/data/data/com.termux/files/usr/bin/bash
# Chotovai Agent — Termux installer
set -e
echo "📦 প্যাকেজ ইনস্টল হচ্ছে..."
pkg update -y
pkg install -y nodejs termux-api termux-services

DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$DIR"

if [ ! -f .env ]; then
  cp .env.example .env
  echo
  read -rp "🤖 Telegram bot token দাও: " TOKEN
  read -rp "🔑 Gemini API key দাও: " KEY
  sed -i "s|^TELEGRAM_BOT_TOKEN=.*|TELEGRAM_BOT_TOKEN=$TOKEN|" .env
  sed -i "s|^GEMINI_API_KEY=.*|GEMINI_API_KEY=$KEY|" .env
  chmod 600 .env
fi

termux-wake-lock || true
echo
echo "✅ ইনস্টল শেষ। চালাতে:  cd $DIR && bash run.sh"
