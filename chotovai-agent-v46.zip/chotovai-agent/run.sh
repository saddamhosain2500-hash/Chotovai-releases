#!/data/data/com.termux/files/usr/bin/bash
# Run the agent and restart it automatically if it ever crashes.
# Also makes it start by itself after the phone reboots (needs the Termux:Boot app, opened once).
DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$DIR"
mkdir -p data ~/.termux/boot
cat > ~/.termux/boot/start-agent.sh <<BOOT
#!/data/data/com.termux/files/usr/bin/bash
termux-wake-lock
bash "$DIR/run.sh" >> "$DIR/data/agent.log" 2>&1
BOOT
chmod +x ~/.termux/boot/start-agent.sh
termux-wake-lock 2>/dev/null

# keep the log file small
L="$DIR/data/agent.log"; [ -f "$L" ] && [ "$(wc -c < "$L")" -gt 1000000 ] && tail -c 200000 "$L" > "$L.tmp" && mv -f "$L.tmp" "$L"

trap 'echo; echo "⏹ বট বন্ধ করা হলো"; exit 0' INT TERM
while true; do
  node src/index.js
  code=$?
  [ $code -eq 3 ] && exit 0            # another copy is already running
  [ $code -eq 130 ] && exit 0          # stopped with CTRL + c
  if [ $code -eq 75 ]; then            # asked to restart (settings, update…) → right away
    echo "↻ রিস্টার্ট হচ্ছে…"; sleep 1; continue
  fi
  echo "⚠️ বট বন্ধ হয়ে গেছে (code $code) — ১০ সেকেন্ড পর আবার চালু করছি…"
  sleep 10
done
