#!/data/data/com.termux/files/usr/bin/bash
# One-time setup so the Chotovai Android app can start/stop the bot.
mkdir -p ~/.termux
P=~/.termux/termux.properties
touch "$P"
sed -i '/^\s*allow-external-apps/d' "$P"
echo "allow-external-apps = true" >> "$P"
termux-reload-settings 2>/dev/null
echo "✅ হয়ে গেছে। এখন Chotovai অ্যাপ খুলে 'সংযোগ করো' চাপো।"
