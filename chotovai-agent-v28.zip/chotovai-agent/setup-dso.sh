#!/data/data/com.termux/files/usr/bin/bash
# Connect this phone's bot to the Upay DSO phone over Wi-Fi (Android "Wireless debugging").
cd "$(dirname "$0")"
say() { printf '\n\033[1;36m%s\033[0m\n' "$*"; }

say "১/৪  adb বসাচ্ছি…"
pkg install -y android-tools >/dev/null 2>&1 || { echo "android-tools বসানো যায়নি"; exit 1; }
adb start-server >/dev/null 2>&1

cat <<'TXT'

২/৪  DSO ফোনে:
  Settings → Developer options → Wireless debugging (নামের ওপর চাপো, সুইচে না)
  → "Pair device with pairing code" চাপো।
  একটা ৬ অঙ্কের কোড আর "IP address & Port" দেখাবে (যেমন 192.168.0.105:37123)।
  ওই পাতা খোলা রেখেই নিচে লেখো।
TXT
read -rp "Pairing-এর IP address & Port: " PAIR
read -rp "৬ অঙ্কের Pairing code: " CODE
if ! adb pair "$PAIR" "$CODE" 2>&1 | tee /dev/stderr | grep -qi "success"; then
  say "❌ Pairing হয়নি। কোড আর IP:Port আবার দেখে স্ক্রিপ্টটা আবার চালাও।"; exit 1
fi

cat <<'TXT'

৩/৪  এবার DSO ফোনে Pairing-এর ছোট পাতাটা বন্ধ করো।
  Wireless debugging পাতার একদম ওপরে "IP address & Port" লেখা আছে
  (Pairing-এর পোর্ট থেকে আলাদা) — সেটা লেখো।
TXT
read -rp "IP address & Port: " CONN
if ! adb connect "$CONN" 2>&1 | tee /dev/stderr | grep -qi "connected to"; then
  say "❌ যুক্ত হয়নি। দুটো ফোন একই Wi-Fi-তে আছে কিনা দেখে আবার চালাও।"; exit 1
fi

say "৪/৪  পরীক্ষা করছি…"
adb -s "$CONN" shell svc power stayon true    # keep the DSO phone's screen on while it is charging
SIZE=$(adb -s "$CONN" shell wm size | tr -d '\r')
echo "DSO ফোনের স্ক্রিন: $SIZE"
touch .env
if grep -q '^DSO_ADB=' .env; then sed -i "s|^DSO_ADB=.*|DSO_ADB=$CONN|" .env; else echo "DSO_ADB=$CONN" >> .env; fi
say "✅ DSO ফোন যুক্ত হয়েছে! এখন ছোটভাই অ্যাপে ↻ রিস্টার্ট চাপো, তারপর বটকে বলো: \"DSO ফোনের স্ক্রিন দেখাও\""
